package utils;

public class Utilities {

    /**
     * This method takes in a decimal point number and truncates it to two decimal places.  Note
     * that the method does NOT round when truncating; the numbers after the two decimal places are
     * just removed.
     *
     * The method does the truncating in this manner:
     *  - multiply the number by 100 e.g. 16.543235523 * 100 = 1654.3235523
     *  - cast the multiplied number as an in e.g. 1654.3235523 = 1654
     *  - finally, the multiplied and casted number is divided by 100 and returned e.g. 1654 = 16.54
     *
     * @param number  Number to be truncated to two decimal places
     * @return  the number, passed as a parameter, truncated to two decimal places (note: not rounded)
     */
    public static double toTwoDecimalPlaces(double number){
        return (int) (number * 100 ) / 100.0;
    }

    public static boolean YNtoBoolean(char charToConvert){
        return ((charToConvert == 'y') || (charToConvert == 'Y'));
    }
}