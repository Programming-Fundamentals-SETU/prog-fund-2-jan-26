package main;

import controllers.WearableDeviceAPI;

import models.*;
import utils.ScannerInput;
import utils.Utilities;

import java.io.File;

public class Driver {


    private WearableDeviceAPI wearableAPI;

    //  private AppStoreAPI appStoreAPI;

    public static void main(String[] args) throws Exception {
        new Driver().start();
    }

    public void start() {

        wearableAPI = new WearableDeviceAPI(new File("wearableDevices.xml"));


        loadAllData();  //load all data once the serializers are set up
        runMainMenu();
    }

    private int mainMenu() {
        System.out.println("""
                 -------WearableDevice Store-------------
                |  1) WearableDevice  CRUD MENU         |
                |  2) Reports MENU                      |
                |---------------------------------------|
                |  4) Search WearableDevice Devices     |  
                |  5) Sort WearableDevice Devices       | 
                |---------------------------------------|
                |  10) Save all                         |
                |  11) Load all                         |
                |---------------------------------------|
                |  0) Exit                              |
                 ---------------------------------------""");
        return ScannerInput.readNextInt("==>> ");
    }

    //// search todo by different criteria i.e. look at the list methods and give options based on that.
// sort todo (and give a list of options - not a recurring menu thou)
    private void runMainMenu() {
        int option = mainMenu();
        while (option != 0) {
            switch (option) {

                case 1 -> runwearableAPIMenu();
                case 2 -> runReportsMenu();
                case 10 -> saveAllData();
                case 11 -> loadAllData();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = mainMenu();
        }
        exitApp();
    }

    private void exitApp() {
        saveAllData();
        System.out.println("Exiting....");
        System.exit(0);
    }




    //---------------------
    //  App Store Menu
    //---------------------

    private int wearableAPIMenu() {
        System.out.println(""" 
                 -----WearableDevice Store Menu----- 
                | 1) Add a Wearable Device           |
                | 2) Delete a Wearable Device        |
                | 3) List all Wearable Devices       |
                | 4) Update Wearable Device          |
                | 0) Return to main menu             |
                 ------------------------------------""");
        return ScannerInput.readNextInt("==>>");
    }

    private void runwearableAPIMenu() {
        int option = wearableAPIMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> addTech();
                case 2 -> deleteTech();
                case 3 -> System.out.println(wearableAPI.listAllWearableDevices());
                case 4 -> System.out.println("todo");
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = wearableAPIMenu();
        }
    }

    private void deleteTech() {
        String id = ScannerInput.readNextLine("Please enter id number to delete: ");

        if (wearableAPI.isValidId(id)) {
            WearableDevice t = wearableAPI.deleteWearableDeviceById(id);
            if (t != null)
                System.out.println("Sucessful delete : " + t);
            else System.out.println("No WearableDevice was deleted");
        }

    }

    // public Vehicle(String regNumber, String  model, float cost, Manufacturer manufacturer, int  year) {
    private void addTech() {
        int techType = ScannerInput.readNextInt("""
                 Which type of technology do you wish to add? 
                 1) SmartBand
                 2) SmartWatch
                """);

        String manufacturer = ScannerInput.readNextLine("Enter Manufacturer Name: ");
        //validate name
        if (manufacturer != null) {
            String id = ScannerInput.readNextLine("Please enter id number: ");


            if (wearableAPI.isValidId(id)) {
                String name = ScannerInput.readNextLine("\tname : ");
                double price = ScannerInput.readNextFloat("\tprice : ");
                String size = ScannerInput.readNextLine("\tsize : ");
                String material = ScannerInput.readNextLine("\tmaterial :");
                switch (techType) {

                    case 1 -> {
                        //smartband
                        char monit = ScannerInput.readNextChar("\theart monitor? y/n : ");
                        boolean monitor = Utilities.YNtoBoolean(monit);

                        wearableAPI.addWearableDeviceDevice(new SmartBand(name, price, manufacturer, id, size, material, monitor));
                    }
                    case 2 -> {
                        //Smart Watch

                        String display = ScannerInput.readNextLine("\tdisplay : ");
                        wearableAPI.addWearableDeviceDevice(new SmartWatch(name, price, manufacturer, id, size, material, display));

                    }

                }
            } else {
                System.out.println("This id number already exists.");
            }
        } else {
            System.out.println("Manufacturer name is NOT valid");
        }
    }


    public void runReportsMenu() {
        int option = reportsMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> runTechReportsMenu();
                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = reportsMenu();
        }
    }

    private int reportsMenu() {
        System.out.println(""" 
                 --------Reports Menu ---------
                | 1) WearableDevice Overview    |
                | 0) Return to main menu        | 
                  -----------------------------  """);
        return ScannerInput.readNextInt("==>>");
    }

    public void runTechReportsMenu() {
        int option = techReportsMenu();
        while (option != 0) {
            switch (option) {
                case 1 -> System.out.println(wearableAPI.listAllWearableDevices());
                case 2 -> System.out.println(wearableAPI.listAllSmartBands());
                case 3 -> System.out.println(wearableAPI.listAllSmartWatches());
                case 4 -> listAllWearableDeviceAbove();
                case 5 -> listAllWearableDeviceBelowPrice();
                case 6 -> System.out.println(wearableAPI.topFiveMostExpensiveSmartWatch());
                case 7 -> listAllTechFromaGivenManufacturer();

                default -> System.out.println("Invalid option entered" + option);
            }
            ScannerInput.readNextLine("\n Press the enter key to continue");
            option = techReportsMenu();
        }
    }

    private int techReportsMenu() {
        System.out.println(""" 
                 ---------- WearableDevice Reports Menu  ---------------------
                | 1) List all technology                                 | 
                | 2) List all SmartBands                                 |
                | 3) List all Smart watch                                |
                | 4) List all devices above a price                      |
                | 5) List all devices below a price                      |
                | 6) List the top five most expensive smart watches      |
                | 7) List all devices for a chosen Manufacturer          |
                | 0) Return to main menu                                 | 
                  ----------------------------------------------------  """);
        return ScannerInput.readNextInt("==>>");
    }



    //todo update methods counting methods
    public void listAllWearableDeviceBelowPrice() {
        double price = ScannerInput.readNextDouble("What price do you want to see technology below (inclusive)?  : ");
        System.out.println(wearableAPI.listAllWearableDeviceBelowPrice(price));
    }

    public void listAllWearableDeviceAbove() {
        double price = ScannerInput.readNextDouble("What price do you want to see technology above (inclusive)?  : ");
        System.out.println(wearableAPI.listAllWearableDeviceAbovePrice(price));
    }

    public void listAllTechFromaGivenManufacturer() {
        String manu = ScannerInput.readNextLine("What manufacturer you want a list of tech for?  : ");
        //validat name
        if (!(manu == null))
            System.out.println(wearableAPI.listAllTechDevicesByChosenManufacturer(manu));
        else
            System.out.println("No manufacturer with tha name exists");
    }


    //---------------------
    //  General Menu Items
    //---------------------

    private void saveAllData() {
        System.out.println("Storing all data....");
        try {
            wearableAPI.save();

        } catch (Exception e) {
            System.err.println("Error writing to file: " + e);
        }
    }

    private void loadAllData() {
        System.out.println("Loading all data....");
        try {
            wearableAPI.load();

        } catch (Exception e) {
            System.err.println("Error loading from this file:  " + e);
        }
    }

    //---------------------
    //  Helper Methods
    //---------------------

    private String getValidId() {
        String id = ScannerInput.readNextLine("\tID Number (must be unique): ");
        if (wearableAPI.isValidId(id)) {
            return id;
        } else {
            System.err.println("\tId already exists / is not valid.");
            return "";
        }
    }




}

