package models;

import utils.ManufacturerNameUtility;
import utils.Utilities;

// WearableDevices class extending Technology
public abstract class WearableDevice  {
    private String modelName; //max 30 chars
    private double price = 20.0; // >=20 default to 20
    private String manufacturerName = "Not Valid";
    private String id = "unknown"; //default unknown 10 chars or less
    private String size; //10 chars or less
    private String material;  //20 chars or less

    // Constructor

    public abstract String connectToInternet();
    public abstract double getInsurancePremium();
    public WearableDevice(String modelName, double price, String manufacturer, String id, String size, String material) {
        this.modelName = Utilities.truncateString(modelName, 30);
        setPrice(price);
        setManufacturer(manufacturer);
        setId(id);
        this.size = Utilities.truncateString(size, 10);
        this.material = Utilities.truncateString(material, 20);
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        if(utils.Utilities.validStringlength(id, 10))
            this.id = id;
    }

    // Getters and setters
    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        if(utils.Utilities.validStringlength(modelName, 30))
            this.modelName = modelName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if(price>=20.0)
            this.price = price;
    }

    public String getManufacturer() {
        return manufacturerName;
    }

    public void setManufacturer(String manufacturer) {
        if(ManufacturerNameUtility.isValidManuName(manufacturer))
            this.manufacturerName = manufacturer;
    }
    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        if(Utilities.validStringlength(size, 10))
            this.size = size;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        if(Utilities.validStringlength(material, 20))
        this.material = material;
    }

    @Override
    public String toString() {
        return "WearableDevice{" +
                "modelName='" + modelName + '\'' +
                ", price=" + price +
                ", manufacturer=" + manufacturerName +
                ", id='" + id + '\'' +
                ", size='" + size + '\'' +
                ", material='" + material + '\'' +
                '}';
    }
}
