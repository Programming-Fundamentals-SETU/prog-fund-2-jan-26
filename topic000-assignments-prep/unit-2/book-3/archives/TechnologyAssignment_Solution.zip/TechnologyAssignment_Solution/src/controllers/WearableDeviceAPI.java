package controllers;

import models.*;

import utils.ISerializer;

import utils.Utilities;

import java.io.*;
import java.util.*;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;


public class WearableDeviceAPI implements ISerializer {
    private List<WearableDevice> wearableList = new ArrayList<>();
    private File file;

    public WearableDeviceAPI(File file)  {
    this.file = file;
}
    public boolean addWearableDeviceDevice(WearableDevice techDevice) {
        //if the device id doesn't exist in the arraylist, add it
        if (techDevice != null)
            if (techDevice.getId() != null)
                if (getWearableDeviceDeviceById(techDevice.getId()) == null) {
                    return wearableList.add(techDevice);
        }
        return false;
    }



    public int numberOfWearableDeviceDevices(){
        return wearableList.size();
    }


    public int numberOfSmartBands(){
        return wearableList.stream().filter(it -> it instanceof SmartBand).toList().size();
    }
    public int numberOfSmartWatch(){
        return wearableList.stream().filter(it -> it instanceof SmartWatch).toList().size();
    }
    //---------------------
    // Read methods
    //---------------------
    public String listAllWearableDevices(){
        String listAllTech = "";
        for (WearableDevice techDev: wearableList){
            listAllTech += wearableList.indexOf(techDev) + ": " + techDev + "\n";
        }
        return listAllTech.equals("") ? "No WearableDevice Devices" : listAllTech;
    }

    public String listAllSmartBands(){
        String listAllSmartBandsStr = "";
        for (WearableDevice techDev: wearableList){
            if (techDev instanceof SmartBand) {
                listAllSmartBandsStr += wearableList.indexOf(techDev) + ": " + techDev + "\n";
            }
        }
        return listAllSmartBandsStr.equals("") ? "No Smart Bands" : listAllSmartBandsStr;
    }

    public String listAllSmartWatches(){
        String listAllSmartWatchStr = "";
        for (WearableDevice techDev: wearableList){
            if (techDev instanceof SmartWatch) {
                listAllSmartWatchStr += wearableList.indexOf(techDev) + ": " + techDev + "\n";
            }
        }
        return listAllSmartWatchStr.equals("") ? "No Smart Watches" : listAllSmartWatchStr;
    }

    //todo leave this method in starter
    public boolean isValidId(String id) {
        for (WearableDevice techDev : wearableList) {
            if (techDev.getId().equals(id))
                return false;
        }
            return true;
        }

    public String listAllWearableDeviceAbovePrice(double price){
        String listAllWearableDeviceAbovePriceStr = "";
            for (WearableDevice techDev: wearableList){
                if (techDev.getPrice() >= price) {
                    listAllWearableDeviceAbovePriceStr += wearableList.indexOf(techDev) + ": " + techDev + "\n";
                }
            }

        return listAllWearableDeviceAbovePriceStr.equals("") ? "No wearable device more expensive than "
                + price : listAllWearableDeviceAbovePriceStr;
    }

    public String listAllWearableDeviceBelowPrice(double price){
        String listAllWearableDeviceBelowPriceStr = "";
        for (WearableDevice techDev: wearableList){
            if (techDev.getPrice() <= price) {
                listAllWearableDeviceBelowPriceStr += wearableList.indexOf(techDev) + ": " + techDev + "\n";
            }
        }

        return listAllWearableDeviceBelowPriceStr.equals("") ? "No wearable device cheaper than "
                + price : listAllWearableDeviceBelowPriceStr;
    }



    public String listAllTechDevicesByChosenManufacturer(String manufacturer) {
        String listAllTechDevicesStr = "";
        for (WearableDevice techDev: wearableList){
            if (techDev.getManufacturer().equalsIgnoreCase(manufacturer)){
                listAllTechDevicesStr += wearableList.indexOf(techDev) + ": " + techDev + "\n";
            }
        }
        return listAllTechDevicesStr.equals("") ?
                "No technology manufactured by  " + manufacturer : listAllTechDevicesStr;
    }

    public int numberOfWearableDeviceByChosenManufacturer(String manufacturer) {
        int numTechDevices = 0;
        for (WearableDevice techDev: wearableList){
            if (techDev.getManufacturer().equalsIgnoreCase(manufacturer)){
                numTechDevices++;
                 }
        }
        return numTechDevices;
    }

    public WearableDevice getWearableDeviceDeviceById(String id) {
        for(WearableDevice compDev:wearableList){
            if(compDev.getId().equalsIgnoreCase(id))
                return compDev;
        }

        return null;
    }
    public WearableDevice getWearableDeviceByIndex(int index){
       if (Utilities.isValidIndex(wearableList, index)){
           return wearableList.get(index);
        }
        return null;
    }

    public WearableDevice deleteWearableDeviceById(String id){
        WearableDevice tech = getWearableDeviceDeviceById(id);
        if ((tech != null)){
            wearableList.remove(tech);
            return tech;
        }
        return null;
    }

    public WearableDevice deleteWearableDeviceByIndex(int index){
        if (Utilities.isValidIndex(wearableList,index)){
            return wearableList.remove(index);
        }
        return null;
    }

    //----------------------------------------------
    //Reduced sorting code just to get tests written
    //----------------------------------------------
    public void sortByPriceDescending() {
        wearableList.sort(Comparator.comparingDouble(WearableDevice::getPrice).reversed());
    }

    public void sortByPriceAscending() {
        wearableList.sort(Comparator.comparingDouble(WearableDevice::getPrice));
    }

public void swapWearableDevice (List<WearableDevice> wearableList, int i, int j){

}

    public List<WearableDevice> topFiveMostExpensiveWearableDevice (){
        sortByPriceAscending();  //sort by lowest to highest price
        return wearableList.stream()
                .limit(5)
                .toList();
    }

    public List<WearableDevice> topFiveMostExpensiveSmartWatch (){
        sortByPriceAscending();  //sort by lowest to highest .
        return wearableList.stream()
                .filter(it -> it instanceof SmartWatch)
                .limit(5)
                .toList();
    }


    public boolean updateSmartWatch(String id, SmartWatch updatedDetails)  {
        WearableDevice foundDevice= getWearableDeviceDeviceById(id);

        if ((foundDevice instanceof SmartWatch)){
            //Generic Fields in Tech
            foundDevice.setPrice(updatedDetails.getPrice());
            foundDevice.setModelName(updatedDetails.getModelName());
            foundDevice.setManufacturer(updatedDetails.getManufacturer());

            //Generic Fields in ComputingDevice
            ((SmartWatch) foundDevice).setSize(updatedDetails.getSize());
            ((SmartWatch) foundDevice).setMaterial(updatedDetails.getMaterial());
            //Specific Fields
            ((SmartWatch) foundDevice).setDisplayType(updatedDetails.getDisplayType());
            return true;
        }
        return false;
    }

    public boolean updateSmartBand(String id, SmartBand updatedDetails)  {
        WearableDevice foundDevice= getWearableDeviceDeviceById(id);

        if ((foundDevice instanceof SmartBand)){
            //Generic Fields in Tech
            foundDevice.setPrice(updatedDetails.getPrice());
            foundDevice.setModelName(updatedDetails.getModelName());
            foundDevice.setManufacturer(updatedDetails.getManufacturer());

            //Generic Fields in ComputingDevice
            ((SmartBand) foundDevice).setSize(updatedDetails.getSize());
            ((SmartBand) foundDevice).setMaterial(updatedDetails.getMaterial());
            //Specific Fields
            ((SmartBand) foundDevice).setHeartRateMonitor(updatedDetails.isHeartRateMonitor());
            return true;
        }
        return false;
    }

    //---------------------
    // Persistence methods
    //---------------------
    /**
     * The load method uses the XStream component to read all the objects from the xml
     * file stored on the hard disk.  The read objects are loaded into the associated ArrayList
     *
     * @throws Exception An exception is thrown if an error occurred during the load e.g. a missing file.
     */
    @SuppressWarnings("unchecked")
    public void load() throws Exception {
        //list of classes that you wish to include in the serialisation, separated by a comma
        Class<?>[] classes = new Class[]{WearableDevice.class,  WearableDevice.class,
                                            SmartWatch.class, SmartBand.class};

        //setting up the xstream object with default security and the above classes
        XStream xstream = new XStream(new DomDriver());
        XStream.setupDefaultSecurity(xstream);
        xstream.allowTypes(classes);

        //doing the actual serialisation to an XML file
        ObjectInputStream in = xstream.createObjectInputStream(new FileReader(file));
        wearableList = (List<WearableDevice>) in.readObject();
        in.close();
    }

    /**
     * The save method uses the XStream component to write all the objects in the ArrayList
     * to the xml file stored on the hard disk.
     *
     * @throws Exception An exception is thrown if an error occurred during the save e.g. drive is full.
     */
    public void save() throws Exception {
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter(file));
        out.writeObject(wearableList);
        out.close();
    }

    public String fileName(){
        return this.file.toString();
    }


}
