package models;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;


public class Dog {
    //TODO add a constant DANGEROUS_DAILY_RATE, make it equal to 40.0
    //TODO add a constant NONDANGEROUS_DAILY_RATE, make it equal to 30.0

    //TODO The id (int id)  in the system is entered by the user.
    //     Default value is 1000.
    //     When creating the Dog, must be an id between 1000 and 9990
    //     When updating an existing Dog, only update the  id if between 1000 and 9999

    //TODO The  name (String name)  in the system is entered by the user.
    //     Default value is "".
    //     When creating the Dog, truncate the name to 20 characters.
    //     When updating an existing Dog, only update the name if it is 20 characters or less.

    //TODO boolean dangerousBreed defaults to false

    //TODO The age (int age)  in the system is entered by the user.
    //     Default value is 5.
    //     When creating the Dog, must be an id between 0 and 20
    //     When updating an existing Dog, only update the  id if between 1000 and 9999

    //TODO char sex -  MUST BE M OR F / default to 'F'

    //TODO boolean neutered defaults to false

    //TODO ArrayList of owners

    //TODO boolean Array called daysInKennel, defaults to false, stores 5 days
    //   leave at 5 day (so easy to remember starts Monday)

    //TODO add constructor Dog(int,String , String , boolean , int , char , boolean , Owner ) {

    //TODO Add a getter and setter for each field, that adheres to the above validation rules


    //TODO Add a generated equals method.



    //TODO create a method called numOfDaysInKennel that returns an int

    //TODO create a method called listOwners that returns a String

    //TODO create a method called getweeklyBill that returns a float with the weekly cost of the dog (num of days * cost)


    //TODO The toString should return the string containing each of the field values including the use of the listOwners()
    //  should print male neutered or female not neutered
    //    should print days that the dog is booked into kennels
}

