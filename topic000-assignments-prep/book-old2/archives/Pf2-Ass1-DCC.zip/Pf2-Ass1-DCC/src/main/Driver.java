package main;

import controllers.DayCare;
import models.*;

import java.util.ArrayList;
import java.util.Scanner;


public class Driver {
    //TODO Define an object of the DayCare here.  It should be declared private.
    public static void main(String[] args) {

        new Driver();

    }

    //TODO Refer to the tutors instructions for building this class and for the menu.  You are free to deviate in any way
    //     from the Driver menu that is in the tutors instructions, once you have these included:
    //     (with tests still compiling)
    //       - CRUD on DayCare
    //       - Search facility (for Dogs and Owners)
    //       - Reports
    //       - Persistence
    // Note:  This is the ONLY class that can talk to the user i.e. have System.out.print and Scanner reads in it.

    //----------------------------------------------------------------------------
    // Private methods for displaying the menu and processing the selected options
    //----------------------------------------------------------------------------


    //------------------------------------
    // Private methods for CRUD on Dog
    //------------------------------------


    //-----------------------------------------------------------------
    //  Private methods for Search facility
    //-----------------------------------------------------------------


    //-----------------------------
    //  Private methods for Reports
    // ----------------------------


    //---------------------------------
    //  Private methods for Persistence
    // --------------------------------

}
