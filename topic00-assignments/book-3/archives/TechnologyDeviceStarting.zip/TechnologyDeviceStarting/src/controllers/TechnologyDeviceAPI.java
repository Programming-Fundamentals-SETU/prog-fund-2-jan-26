package controllers;

import models.*;

import utils.ISerializer;
import utils.OperatingSystemUtility;

import utils.Utilities;

import java.io.*;
import java.util.*;



//TODO - ensure that this class implements iSerializer
public class TechnologyDeviceAPI {
    //TODO - create 2 fields

    //TODO - create constructor
   //TODO - CRUD Methods




    //TODO - Number methods


    // TODO Read/list methods


    //leave this method in starter
    //the following is isValidId can be updated
    //to suit your code
    /*public boolean isValidId(String id) {
        for (Technology techDev : technologyList) {
            if (techDev.getId().equals(id))
                return false;
        }
            return true;
        }
*/

    //TODO get Technology methods

   //TODO - delete methods



    //TODO - sort methods

    //TODO Top 5 methods





    // TODO Persistence methods




}
