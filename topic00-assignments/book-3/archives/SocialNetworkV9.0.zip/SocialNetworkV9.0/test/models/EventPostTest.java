package models;

public class EventPostTest {
}
